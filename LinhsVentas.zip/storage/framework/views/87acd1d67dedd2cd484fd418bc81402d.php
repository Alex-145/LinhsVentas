<div
    class="<?php echo e($menuAbierto ? 'ml-60' : 'ml-0'); ?> mt-16 max-w-7xl mx-auto p-6 bg-gradient-to-br from-blue-50 to-indigo-100 shadow-xl rounded-xl transition-all duration-300 ease-in-out">
    <div class="flex space-x-4">
        <!-- Div de Ganancias Totales -->
        <div class="p-4 mb-4 bg-green-100 rounded-lg shadow-inner flex-1">
            <h3 class="font-bold text-lg">Ganancias Totales</h3>
            <p class="text-xl text-green-800">S/.<?php echo e(number_format($totalGains, 2)); ?></p>
        </div>

        <!-- Div de Total de Ventas -->
        <div class="p-4 mb-4 bg-blue-100 rounded-lg shadow-inner flex-1">
            <h3 class="font-bold text-lg">Total de Ventas</h3>
            <p class="text-xl text-blue-800">S/.<?php echo e(number_format($totalSales, 2)); ?></p>
        </div>
    </div>

    <div class="space-y-4">
        <!-- Botón de filtros -->
        <div class="flex justify-end space-x-4">
            <!--[if BLOCK]><![endif]--><?php if(!$isPendienteFacturacion): ?>
                <button wire:click="openModal"
                    class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 px-6 rounded-lg shadow-md transition duration-300 ease-in-out transform hover:scale-105 hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-opacity-50">
                    Filtros
                </button>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <a href="https://api-seguridad.sunat.gob.pe/v1/clientessol/4f3b88b3-d9d6-402a-b85d-6a0bc857746a/oauth2/loginMenuSol?lang=es-PE&showDni=true&showLanguages=false&originalUrl=https://e-menu.sunat.gob.pe/cl-ti-itmenu/AutenticaMenuInternet.htm&state=rO0ABXNyABFqYXZhLnV0aWwuSGFzaE1hcAUH2sHDFmDRAwACRgAKbG9hZEZhY3RvckkACXRocmVzaG9sZHhwP0AAAAAAAAx3CAAAABAAAAADdAAEZXhlY3B0AAZwYXJhbXN0AEsqJiomL2NsLXRpLWl0bWVudS9NZW51SW50ZXJuZXQuaHRtJmI2NGQyNmE4YjVhZjA5MTkyM2IyM2I2NDA3YTFjMWRiNDFlNzMzYTZ0AANleGVweA=="
                target="_blank"
                class="bg-gray-600 hover:bg-gray-700 text-white font-semibold py-2 px-4 rounded-lg shadow-md flex items-center space-x-2 transition duration-300 ease-in-out transform hover:scale-105 hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-opacity-50">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24"
                    stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                </svg>
                <span>SUNAT</span>
            </a>
        </div>

        <!-- Modal de filtros -->
        <!--[if BLOCK]><![endif]--><?php if($isOpen): ?>
            <?php echo $__env->make('livewire.fiterventas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        <!-- Campo de búsqueda -->
        <div>
            <input type="text" wire:model="search" wire:keydown.debounce.300ms="loadSales"
                placeholder="Buscar por nombre de cliente"
                class="w-full py-2 px-4 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 transition duration-200 ease-in-out hover:border-indigo-500 placeholder-gray-500">
        </div>
    </div>

    <div class="container mx-auto mt-8">
        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="mt-8 overflow-x-auto">
                <table class="min-w-full bg-white border border-gray-300 shadow-md rounded-lg overflow-hidden">
                    <thead class="bg-gray-100">
                        <tr>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = ['ID' => 'id', 'Fecha de Venta' => 'sale_date', 'Día de la Semana' => 'sale_date', 'Usuario' => 'user.name', 'Cliente' => 'client.name', 'Total' => 'total', 'Utilidad' => 'utilidad_sale', 'Estado de la Factura' => 'status_fac', 'Acciones' => '']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th
                                    class="py-3 px-4 border-b text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    <?php echo e($label); ?>

                                </th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="cursor-pointer hover:bg-gray-50 transition-colors duration-200"
                            wire:key="sale-<?php echo e($sale->id); ?>">
                            <td class="py-3 px-4 border-b" wire:click="selectSale(<?php echo e($sale->id); ?>)">
                                <?php echo e($sale->id); ?>

                            </td>
                            <td class="py-3 px-4 border-b" wire:click="selectSale(<?php echo e($sale->id); ?>)">
                                <?php echo e(\Carbon\Carbon::parse($sale->sale_date)->format('d/m/Y')); ?>

                            </td>
                            <td class="py-3 px-4 border-b" wire:click="selectSale(<?php echo e($sale->id); ?>)">
                                <?php echo e(\Carbon\Carbon::parse($sale->sale_date)->isoFormat('dddd')); ?>

                            </td>
                            <td class="py-3 px-4 border-b" wire:click="selectSale(<?php echo e($sale->id); ?>)">
                                <?php echo e($sale->user->name); ?>

                            </td>
                            <td class="py-3 px-4 border-b" wire:click="selectSale(<?php echo e($sale->id); ?>)">
                                <?php echo e($sale->client->name); ?>

                            </td>
                            <td class="py-3 px-4 border-b" wire:click="selectSale(<?php echo e($sale->id); ?>)">
                                <?php echo e(number_format($sale->total, 2)); ?>

                            </td>
                            <td class="py-3 px-4 border-b bg-green-100 text-green-800 font-semibold"
                                wire:click="selectSale(<?php echo e($sale->id); ?>)">
                                <?php echo e(number_format($sale->utilidad_sale, 2)); ?>

                            </td>
                            <td class="py-3 px-4 border-b" wire:click="selectSale(<?php echo e($sale->id); ?>)">
                                <span
                                    class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full
                                    <?php echo e($sale->status_fac === 'pendiente_facturacion'
                                        ? 'bg-yellow-100 text-yellow-800'
                                        : ($sale->status_fac === 'no_aplicable'
                                            ? 'bg-gray-100 text-gray-800'
                                            : 'bg-green-100 text-green-800')); ?>">
                                    <?php echo e(ucfirst($sale->status_fac)); ?>

                                </span>
                            </td>
                            <td class="py-3 px-4 border-b">
                                <div class="flex items-center space-x-2">
                                    <!--[if BLOCK]><![endif]--><?php if($sale->status_fac === 'pendiente_facturacion'): ?>
                                        <button wire:click="confirmStatusChange(<?php echo e($sale->id); ?>, 'facturado')"
                                            class="text-indigo-600 hover:text-indigo-900 transition-colors duration-200"
                                            title="Marcar como Facturado">
                                            <i class="fas fa-check-circle"></i>
                                        </button>
                                        <button wire:click="showClientInfo(<?php echo e($sale->id); ?>)"
                                            class="text-blue-600 hover:text-blue-900 transition-colors duration-200"
                                            title="Ver Información del Cliente">
                                            <i class="fas fa-info-circle"></i>
                                        </button>
                                    <?php elseif($sale->status_fac === 'no_aplicable'): ?>
                                        <button
                                            wire:click="confirmStatusChange(<?php echo e($sale->id); ?>, 'pendiente_facturacion')"
                                            class="text-green-600 hover:text-green-900 transition-colors duration-200"
                                            title="Cambiar a Pendiente Facturación">
                                            <i class="fas fa-sync-alt"></i>
                                        </button>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    <button wire:click="confirmDelete(<?php echo e($sale->id); ?>)"
                                        class="text-red-600 hover:text-red-900 transition-colors duration-200"
                                        title="Eliminar">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                    <!-- Enlace para descargar el PDF -->
                                    <button wire:click="generateSalePdf(<?php echo e($sale->id); ?>)"
                                        class="text-yellow-600 hover:text-yellow-900 transition-colors duration-200"
                                        title="Generar PDF de la Venta">
                                        <i class="fas fa-file-pdf"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>

                        <!--[if BLOCK]><![endif]--><?php if($selectedSale === $sale->id): ?>
                            <tr>
                                <td colspan="9">
                                    <div class="p-4 bg-gray-50 rounded-lg shadow-inner">
                                        <h3 class="font-bold text-lg mb-4">Detalles de la Venta</h3>
                                        <table
                                            class="min-w-full bg-white border border-gray-300 shadow-sm rounded-lg overflow-hidden">
                                            <thead class="bg-gray-100">
                                                <tr>
                                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = ['ID' => 'id', 'Producto' => 'product.name', 'Cantidad' => 'quantity', 'Precio' => 'price', 'Subtotal' => 'subtotal', 'Utilidad' => 'utilidad_saledetail']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <th
                                                            class="py-2 px-4 border-b text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                            <?php echo e($label); ?>

                                                        </th>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                    <th
                                                        class="py-2 px-4 border-b text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                        Acciones
                                                    </th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $sale->saleDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr class="hover:bg-gray-50">
                                                        <td class="py-2 px-4 border-b">
                                                            <?php echo e($detail->id); ?>

                                                        </td>
                                                        <td class="py-2 px-4 border-b">
                                                            <!--[if BLOCK]><![endif]--><?php if($detail->salable instanceof App\Models\Product || $detail->salable instanceof App\Models\Service): ?>
                                                                <?php echo e($detail->salable->name); ?>

                                                            <?php else: ?>
                                                                No disponible
                                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                        </td>
                                                        <td class="py-2 px-4 border-b"><?php echo e($detail->quantity); ?></td>
                                                        <td class="py-2 px-4 border-b">
                                                            <?php echo e(number_format($detail->price, 2)); ?></td>
                                                        <td class="py-2 px-4 border-b">
                                                            <?php echo e(number_format($detail->subtotal, 2)); ?></td>
                                                        <td
                                                            class="py-2 px-4 border-b bg-green-100 text-green-800 font-semibold">
                                                            <?php echo e(number_format($detail->utilidad_saledetail, 2)); ?>

                                                        </td>
                                                        <td class="py-2 px-4 border-b text-center">
                                                            <button
                                                                wire:click="confirmDeleteDetail(<?php echo e($detail->id); ?>)"
                                                                class="text-red-600 hover:text-red-900 transition-colors duration-200"
                                                                title="Eliminar">
                                                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5"
                                                                    viewBox="0 0 20 20" fill="currentColor">
                                                                    <path fill-rule="evenodd"
                                                                        d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z"
                                                                        clip-rule="evenodd" />
                                                                </svg>
                                                            </button>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                            </tbody>
                                        </table>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    </tbody>
                </table>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="mt-8 text-lg text-gray-600">No hay ventas registradas.</p>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>


    <div x-data="{ open: <?php if ((object) ('showDeleteConfirmationde') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('showDeleteConfirmationde'->value()); ?>')<?php echo e('showDeleteConfirmationde'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('showDeleteConfirmationde'); ?>')<?php endif; ?> }" x-show="open"
        class="fixed inset-0 z-50 flex items-center justify-center bg-gray-800 bg-opacity-50">
        <div class="bg-white p-6 rounded-lg shadow-lg">
            <h2 class="text-lg font-bold mb-4">¿Estás seguro de eliminar este detalle?</h2>
            <div class="flex justify-end">
                <button wire:click="$set('showDeleteConfirmationde', false)"
                    class="bg-gray-300 text-gray-700 px-4 py-2 rounded mr-2">Cancelar</button>
                <button wire:click="deleteDetailSale(<?php echo e($detailToDelete); ?>)"
                    class="bg-red-600 text-white px-4 py-2 rounded">Eliminar</button>
            </div>
        </div>
    </div>


    <!--[if BLOCK]><![endif]--><?php if($showDeleteConfirmation || $showStatusChangeConfirmation): ?>
        <div class="fixed inset-0 flex items-center justify-center bg-gray-700 bg-opacity-50 z-50">
            <div class="bg-white p-6 rounded-lg shadow-xl">
                <h2 class="text-xl font-bold mb-4">¿Está seguro de que desea realizar esta acción?</h2>
                <div class="flex justify-end space-x-4">
                    <button wire:click="cancelAction"
                        class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded transition duration-300 ease-in-out">Cancelar</button>
                    <button wire:click="<?php echo e($showStatusChangeConfirmation ? 'changeStatus' : 'deleteSale'); ?>"
                        class="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded transition duration-300 ease-in-out">Sí,
                        <?php echo e($showStatusChangeConfirmation ? 'cambiar' : 'eliminar'); ?></button>
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if($sales->isNotEmpty()): ?>
        <button wire:click="calculateTithe"
            class="mt-8 bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded-md transition duration-300 ease-in-out transform hover:scale-105">
            Calcular Diezmo
        </button>

        <!--[if BLOCK]><![endif]--><?php if($tithe > 0): ?>
            <div class="mt-4 p-4 bg-green-100 border-l-4 border-green-500 text-green-700">
                <p class="font-bold">El diezmo calculado es: <?php echo e(number_format($tithe, 2)); ?></p>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if($tithe > 0): ?>
        <div class="fixed inset-0 flex items-center justify-center bg-gray-700 bg-opacity-50 z-50">
            <div class="bg-white p-8 rounded-lg shadow-xl">
                <h2 class="text-2xl font-bold mb-4">Diezmo Calculado</h2>
                <p class="text-3xl font-semibold text-green-600"><?php echo e(number_format($tithe, 2)); ?></p>
                <div class="flex justify-end mt-6">
                    <button wire:click="$set('tithe', 0)"
                        class="bg-indigo-500 hover:bg-indigo-600 text-white px-6 py-2 rounded-md transition duration-300 ease-in-out transform hover:scale-105">Cerrar</button>
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <button wire:click="exportSalesReport"
        class="bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-6 rounded-lg shadow-md flex items-center space-x-2 transition duration-300 ease-in-out transform hover:scale-105 hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-opacity-50">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24"
            stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
        </svg>
        <span>Exportar Detalle Completo</span>
    </button>
    <!--[if BLOCK]><![endif]--><?php if($selectedClient): ?>
        <div class="fixed inset-0 flex items-center justify-center bg-gray-700 bg-opacity-50 z-50">
            <div class="bg-white p-8 rounded-lg shadow-xl">
                <h2 class="text-2xl font-bold mb-4">Información del Cliente</h2>
                <p><strong>Nombre:</strong> <?php echo e($selectedClient['name']); ?></p>
                <p><strong>DNI/RUC:</strong> <?php echo e($selectedClient['dni_ruc']); ?></p>
                <p><strong>Razón Social:</strong> <?php echo e($selectedClient['business_name']); ?></p>
                <p><strong>Teléfono:</strong> <?php echo e($selectedClient['phone_number']); ?></p>
                <div class="flex justify-end mt-6">
                    <button wire:click="$set('selectedClient', null)"
                        class="bg-indigo-500 hover:bg-indigo-600 text-white px-6 py-2 rounded-md transition duration-300 ease-in-out transform hover:scale-105">Cerrar</button>
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\laragon\www\LinhsVentas\resources\views/livewire/sales-list.blade.php ENDPATH**/ ?>