<header
    class="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-6 py-4 bg-white border-b <?php echo e($menuAbierto ? 'ml-60' : 'ml-0'); ?> sm:px-4 sm:py-3">
    <div class="flex items-center flex-1">
        <!-- Botón para alternar el menú -->
        <button wire:click="toggleMenu" class="p-2 rounded-full hover:bg-gray-100 sm:p-1">
            <svg class="w-6 h-6 text-gray-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7" />
            </svg>
        </button>
    </div>

    <div class="flex-1">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight sm:text-lg">
            <!--[if BLOCK]><![endif]--><?php if($currentRoute == 'dashboard'): ?>
                Dashboard
            <?php elseif($currentRoute == 'clients.index'): ?>
                Clientes
            <?php elseif($currentRoute == 'products.index'): ?>
                Productos
            <?php elseif($currentRoute == 'sales.create'): ?>
                Nueva Venta
            <?php elseif($currentRoute == 'sales.index'): ?>
                Lista de ventas
            <?php elseif($currentRoute == 'brands.index'): ?>
                Marcas
            <?php elseif($currentRoute == 'categories.index'): ?>
                Categorias
            <?php elseif($currentRoute == 'suppliers.index'): ?>
                Proveedores
            <?php elseif($currentRoute == 'stockentries.create'): ?>
                Nueva Entrada
            <?php else: ?>
                <?php echo e($pageTitle ?? 'Página principal'); ?>

            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </h2>
    </div>

    <div class="flex items-center gap-4 sm:gap-2" x-data="{ open: false }">

        <div wire:poll.5s="checkPendingSales">
            <!-- Botón de notificación -->

            <a href="<?php echo e(route('predicciones')); ?>"
                class="p-2 rounded-full hover:bg-gray-100 relative sm:p-1 text-blue-600 inline-flex items-center justify-center">
                <i class="fas fa-robot text-lg"></i> 
            </a>

            <button @click="open = !open; $dispatch('close-user-modal')"
                class="p-2 rounded-full hover:bg-gray-100 relative sm:p-1"
                :class="{ 'bg-red-100': <?php echo \Illuminate\Support\Js::from($hasNotifications)->toHtml() ?>, 'hover:bg-gray-100': !<?php echo \Illuminate\Support\Js::from($hasNotifications)->toHtml() ?> }">
                <svg class="w-5 h-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                    stroke="currentColor"
                    :class="{ 'text-red-600': <?php echo \Illuminate\Support\Js::from($hasNotifications)->toHtml() ?>, 'text-gray-600': !<?php echo \Illuminate\Support\Js::from($hasNotifications)->toHtml() ?> }">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                </svg>
                <!--[if BLOCK]><![endif]--><?php if($hasNotifications): ?>
                    <span class="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full animate-ping"></span>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </button>



            <!-- Modal de notificación -->
            <!-- Modal de notificación -->
            <div x-show="open" @click.away="open = false"
                class="absolute z-50 mt-2 bg-white border border-gray-300 rounded-lg shadow-lg p-4 right-40 w-72">
                <h3 class="text-lg font-semibold text-gray-800">Notificaciones</h3>

                <!--[if BLOCK]><![endif]--><?php if($hasNotifications): ?>
                    
                    <!--[if BLOCK]><![endif]--><?php if($hasPending): ?>
                        <div class="mt-2 cursor-pointer hover:bg-gray-100 p-4 rounded-lg"
                            wire:click="navegar('sales.index')">
                            <span class="text-sm text-gray-700">Tienes facturas pendientes.</span>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    
                    <!--[if BLOCK]><![endif]--><?php if($lowStockProducts->isNotEmpty()): ?>
                        <div class="mt-4 cursor-pointer hover:bg-gray-100 p-4 rounded-lg"
                            onclick="window.location.href='<?php echo e(route('lowstock.index')); ?>'">
                            <h4 class="text-sm font-semibold text-gray-700">Productos con bajo stock:</h4>
                            <ul class="mt-2 space-y-1">
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $lowStockProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="text-sm text-gray-600">
                                        <?php echo e($product->name); ?> (Stock: <?php echo e($product->stock); ?>)
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </ul>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    
                    <!--[if BLOCK]><![endif]--><?php if($hasVerificacionPendiente): ?>
                        <div class="mt-2 cursor-pointer hover:bg-gray-100 p-4 rounded-lg"
                            onclick="window.location.href='<?php echo e(route('ventas-online.index')); ?>'">
                            <span class="text-sm text-gray-700">Tienes pagos por verificar.</span>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <?php else: ?>
                    
                    <div class="mt-4">
                        <span class="text-sm text-gray-500">No tienes notificaciones.</span>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                <button @click="open = false" class="mt-4 text-sm text-gray-600 hover:text-gray-800">Cerrar</button>
            </div>


        </div>


        <div>
            <!-- Información del usuario -->
            <div class="relative">
                <div class="flex items-center gap-3 cursor-pointer" wire:click="toggleModal">
                    <div class="text-right">
                        <div class="text-sm font-medium"><?php echo e(Auth::user()->name); ?></div>
                        <div class="text-xs text-gray-500">Administrador</div>
                    </div>
                    <img src="<?php echo e(Auth::user()->profile_photo_url); ?>" alt="<?php echo e(Auth::user()->name); ?>"
                        class="w-10 h-10 rounded-full">
                </div>

                <!-- Modal de usuario -->
                <div x-data="{ open: <?php if ((object) ('open') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('open'->value()); ?>')<?php echo e('open'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('open'); ?>')<?php endif; ?> }" x-show="open" @click.away="open = false"
                    class="absolute right-0 mt-2 w-48 bg-white border border-gray-200 rounded-lg shadow-lg">
                    <div class="block px-4 py-2 text-xs text-gray-400"><?php echo e(__('Manage Account')); ?></div>
                    <a href="<?php echo e(route('profile.show')); ?>"
                        class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"><?php echo e(__('Profile')); ?></a>

                    <div class="border-t border-gray-200"></div>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit"
                            class="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"><?php echo e(__('Log Out')); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</header>

<script>
    document.addEventListener('livewire:init', () => {
        let notificationSoundCooldown = false;

        Livewire.on('play-notification-sound', () => {
            if (notificationSoundCooldown) return;

            const audio = new Audio('/storage/audio/audionoti.mp3');
            audio.volume = 1.0;
            audio.play().catch(error => {
                console.error("Error al reproducir el sonido: ", error);
            });

            // Establecer un cooldown de 30 segundos
            notificationSoundCooldown = true;
            setTimeout(() => {
                notificationSoundCooldown = false;
            }, 30000);
        });
    });
</script>
<?php /**PATH C:\laragon\www\LinhsVentas\resources\views/livewire/header.blade.php ENDPATH**/ ?>