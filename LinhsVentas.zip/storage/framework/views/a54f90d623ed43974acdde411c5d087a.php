<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Título de la pestaña -->
    <title>Linhs Llantas | Tu tienda de confianza</title>

    <!-- Favicon (ícono de la pestaña) -->
    <link rel="icon" href="<?php echo e(asset('storage/pageweb/logopeque.png')); ?>" type="image/png">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <!-- Estilos de Livewire y Vite -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>


    <!-- Ocultar elementos con x-cloak hasta que Alpine.js esté listo -->
    <style>
        [x-cloak] {
            display: none !important;
        }
    </style>
</head>

<body>
    <!-- Encabezado -->
    <header class="shadow-md fixed top-0 w-full z-50">
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('pageweb.header');

$__html = app('livewire')->mount($__name, $__params, 'lw-4034599237-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </header>

    <!-- Contenido principal -->
    <main class="pt-16">
        <?php echo e($slot); ?>

    </main>

    <!-- Pie de página -->
    <footer>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('footer');

$__html = app('livewire')->mount($__name, $__params, 'lw-4034599237-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </footer>

    <!-- Componente del carrito flotante -->
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('pageweb.carrito');

$__html = app('livewire')->mount($__name, $__params, 'lw-4034599237-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>


    <!-- Ícono flotante de WhatsApp -->
    <a href="https://wa.me/51983316063?text=Hola%2C%20estoy%20interesado%20en%20sus%20productos"
        class="fixed bottom-6 right-6 z-50" target="_blank" rel="noopener noreferrer">
        <div class="bg-green-500 p-3 rounded-full shadow-lg hover:scale-110 transition-transform duration-300">
            <img src="/storage/pageweb/WhatsApp.svg.webp" alt="WhatsApp" class="w-8 h-8">
        </div>
    </a>
</body>

</html>
<?php /**PATH C:\laragon\www\LinhsVentas\resources\views/layouts/index.blade.php ENDPATH**/ ?>