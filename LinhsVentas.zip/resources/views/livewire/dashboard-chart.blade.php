<div
    class="{{ $menuAbierto ? 'ml-60' : 'ml-0' }} mt-16 max-w-full mx-auto p-4 bg-white shadow-md rounded-lg transition-all duration-300 ease-in-out">
    <h1 class="text-xl font-bold mb-2 text-gray-800">Dashboard de Ventas</h1>
    <div x-data="{ mostrarFiltros: false }" class="mb-4">
        <!-- Botón de Mostrar/Ocultar -->
        <button @click="mostrarFiltros = !mostrarFiltros"
            class="mb-2 px-3 py-1 text-xs bg-blue-500 text-white rounded hover:bg-blue-600">
            <span x-show="!mostrarFiltros">Mostrar Filtros</span>
            <span x-show="mostrarFiltros">Ocultar Filtros</span>
        </button>

        <!-- Sección de Filtros -->
        <div x-show="mostrarFiltros" x-transition class="bg-white p-3 rounded-lg shadow-sm border border-gray-100">
            <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-2">
                <h3 class="text-sm font-semibold text-gray-700">Filtros</h3>
                <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 w-full">
                    <!-- Filtro por Fecha -->
                    <div>
                        <input type="date" id="fechaInicio" wire:model="fechaInicio"
                            class="text-xs w-full rounded-md border-gray-200 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 py-1 px-2">
                    </div>
                    <div>
                        <input type="date" id="fechaFin" wire:model="fechaFin"
                            class="text-xs w-full rounded-md border-gray-200 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 py-1 px-2">
                    </div>

                    <!-- Filtro por Marca -->
                    <div>
                        <select id="marca" wire:model="marcaSeleccionada"
                            class="text-xs w-full rounded-md border-gray-200 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 py-1 px-2">
                            <option value="">Todas Marcas</option>
                            @foreach ($marcas as $marca)
                                <option value="{{ $marca->id }}">{{ $marca->name }}</option>
                            @endforeach
                        </select>
                    </div>

                    <!-- Filtro por Categoría -->
                    <div>
                        <select id="categoria" wire:model="categoriaSeleccionada"
                            class="text-xs w-full rounded-md border-gray-200 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 py-1 px-2">
                            <option value="">Todas Categorías</option>
                            @foreach ($categorias as $categoria)
                                <option value="{{ $categoria->id }}">{{ $categoria->name }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="flex space-x-2 mt-2 md:mt-0">
                    <button wire:click="aplicarFiltros"
                        class="text-xs px-3 py-1 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">
                        Aplicar
                    </button>
                    <button wire:click="resetearFiltros"
                        class="text-xs px-3 py-1 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200">
                        Resetear
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Sección de KPIs/Contadores Compactos -->
    <div class="grid grid-cols-2 md:grid-cols-4 gap-2 mb-4">
        <!-- Ventas Totales -->
        <div class="bg-white p-3 rounded-lg shadow-sm border border-gray-100">
            <div class="flex items-center space-x-2">
                <div class="bg-blue-50 p-2 rounded-full">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-blue-600" fill="none"
                        viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                </div>
                <div>
                    <p class="text-xs text-gray-500">Ventas Totales</p>
                    <p class="text-sm font-semibold text-gray-800">S/. {{ number_format($totalVentas, 2) }}</p>
                </div>
            </div>
        </div>

        <!-- Ventas Promedio -->
        <div class="bg-white p-3 rounded-lg shadow-sm border border-gray-100">
            <div class="flex items-center space-x-2">
                <div class="bg-green-50 p-2 rounded-full">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-green-600" fill="none"
                        viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                    </svg>
                </div>
                <div>
                    <p class="text-xs text-gray-500">Venta Promedio</p>
                    <p class="text-sm font-semibold text-gray-800">S/. {{ number_format($ventaPromedio, 2) }}</p>
                </div>
            </div>
        </div>

        <!-- Productos Vendidos -->
        <div class="bg-white p-3 rounded-lg shadow-sm border border-gray-100">
            <div class="flex items-center space-x-2">
                <div class="bg-purple-50 p-2 rounded-full">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-purple-600" fill="none"
                        viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                    </svg>
                </div>
                <div>
                    <p class="text-xs text-gray-500">Productos Vendidos</p>
                    <p class="text-sm font-semibold text-gray-800">{{ number_format($totalProductos) }}</p>
                </div>
            </div>
        </div>

        <!-- Transacciones -->
        <div class="bg-white p-3 rounded-lg shadow-sm border border-gray-100">
            <div class="flex items-center space-x-2">
                <div class="bg-orange-50 p-2 rounded-full">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-orange-600" fill="none"
                        viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                    </svg>
                </div>
                <div>
                    <p class="text-xs text-gray-500">Transacciones</p>
                    <p class="text-sm font-semibold text-gray-800">{{ number_format($totalTransacciones) }}</p>
                </div>
            </div>
        </div>
    </div>


    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <!-- Ventas Totales -->
        <div class="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Ventas Totales por Fecha (S/.)</h3>
            <div class="h-80">
                <canvas id="ventasChart"></canvas>
            </div>
        </div>

        <!-- Ingresos por Marca -->
        <div class="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Ingresos por Marca (S/.)</h3>
            <div class="h-80">
                <canvas id="marcaChart"></canvas>
            </div>
        </div>
    </div>

    <!-- Ingresos por Categoría (Ancho completo) -->
    <div class="bg-white rounded-xl shadow-lg p-6 border border-gray-100 mb-8">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">Ingresos por Categoría (S/.)</h3>
        <div class="h-72">
            <canvas id="categoriaChart"></canvas>
        </div>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.0.0"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-gradient@0.5.1"></script>

    <script>
        Chart.register(ChartDataLabels);

        // Configuración común
        const fontFamily = "'Inter', 'Segoe UI', 'Helvetica', sans-serif";

        // Paleta de colores profesional
        const colors = {
            primary: {
                base: '#4F46E5',
                light: '#818CF8',
                gradient: ['#4F46E5', '#818CF8']
            },
            secondary: {
                base: '#EC4899',
                light: '#F472B6',
                gradient: ['#EC4899', '#F472B6']
            },
            tertiary: {
                base: '#0EA5E9',
                light: '#38BDF8',
                gradient: ['#0EA5E9', '#38BDF8']
            },
            quaternary: {
                base: '#F59E0B',
                light: '#FBBF24',
                gradient: ['#F59E0B', '#FBBF24']
            },
            success: '#10B981',
            background: '#F9FAFB',
            text: {
                primary: '#111827',
                secondary: '#4B5563'
            }
        };

        // Estilos comunes
        const commonOptions = {
            responsive: true,
            maintainAspectRatio: false,
            animation: {
                duration: 1000,
                easing: 'easeOutQuart'
            },
            plugins: {
                legend: {
                    position: 'top',
                    align: 'end',
                    labels: {
                        boxWidth: 12,
                        usePointStyle: true,
                        pointStyle: 'circle',
                        padding: 20,
                        font: {
                            family: fontFamily,
                            size: 12,
                            weight: '500'
                        }
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(17, 24, 39, 0.9)',
                    titleColor: '#F9FAFB',
                    bodyColor: '#E5E7EB',
                    bodyFont: {
                        family: fontFamily,
                        size: 13
                    },
                    titleFont: {
                        family: fontFamily,
                        size: 14,
                        weight: '600'
                    },
                    padding: 12,
                    cornerRadius: 8,
                    displayColors: false,
                    usePointStyle: true,
                    callbacks: {
                        label: function(context) {
                            let value = context.raw;
                            return value.toLocaleString('es-ES', {
                                style: 'currency',
                                currency: 'EUR',
                                minimumFractionDigits: 0,
                                maximumFractionDigits: 0
                            });
                        }
                    }
                },
                datalabels: {
                    color: '#4B5563',
                    font: {
                        family: fontFamily,
                        weight: '600',
                        size: 11
                    },
                    formatter: function(value) {
                        if (value < 1000) return value;
                        return (value / 1000).toFixed(1) + 'k';
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                        display: false,
                        drawBorder: false
                    },
                    ticks: {
                        font: {
                            family: fontFamily,
                            size: 12
                        },
                        color: '#6B7280',
                        padding: 10
                    }
                },
                y: {
                    grid: {
                        color: 'rgba(229, 231, 235, 0.5)',
                        drawBorder: false
                    },
                    ticks: {
                        font: {
                            family: fontFamily,
                            size: 12
                        },
                        color: '#6B7280',
                        padding: 10,
                        callback: function(value) {
                            if (value >= 1000) {
                                return (value / 1000) + 'k';
                            }
                            return value;
                        }
                    },
                    beginAtZero: true
                }
            }
        };

        // Función para crear gradientes
        function createGradient(ctx, colorStart, colorEnd) {
            const gradient = ctx.createLinearGradient(0, 0, 0, ctx.canvas.height);
            gradient.addColorStop(0, colorStart);
            gradient.addColorStop(1, colorEnd);
            return gradient;
        }

        // Ventas por Fecha (Línea)
        const ventasCtx = document.getElementById('ventasChart').getContext('2d');
        const ventasGradient = createGradient(ventasCtx, 'rgba(79, 70, 229, 0.2)', 'rgba(79, 70, 229, 0.0)');

        new Chart(ventasCtx, {
            type: 'line',
            data: {
                labels: @json(array_keys($ventasPorFecha)),
                datasets: [{
                    label: 'Ventas Totales',
                    data: @json(array_values($ventasPorFecha)),
                    borderColor: colors.primary.base,
                    backgroundColor: ventasGradient,
                    borderWidth: 3,
                    tension: 0.4,
                    pointRadius: 4,
                    pointBackgroundColor: '#FFFFFF',
                    pointBorderColor: colors.primary.base,
                    pointBorderWidth: 2,
                    pointHoverRadius: 6,
                    pointHoverBackgroundColor: colors.primary.base,
                    pointHoverBorderColor: '#FFFFFF',
                    pointHoverBorderWidth: 2,
                    fill: true
                }]
            },
            options: {
                ...commonOptions,
                plugins: {
                    ...commonOptions.plugins,
                    datalabels: {
                        display: false
                    }
                },
                interaction: {
                    mode: 'index',
                    intersect: false
                },
                scales: {
                    ...commonOptions.scales,
                    y: {
                        ...commonOptions.scales.y,
                        title: {
                            display: true,
                            text: 'Ventas (S/.)',
                            font: {
                                family: fontFamily,
                                size: 13,
                                weight: '500'
                            },
                            color: '#6B7280',
                            padding: {
                                top: 0,
                                bottom: 10
                            }
                        }
                    }
                }
            }
        });

        // Ingresos por Marca (Barras)
        const marcaCtx = document.getElementById('marcaChart').getContext('2d');

        new Chart(marcaCtx, {
            type: 'bar',
            data: {
                labels: @json(array_keys($ingresosPorMarca)),
                datasets: [{
                    label: 'Ingresos',
                    data: @json(array_values($ingresosPorMarca)),
                    backgroundColor: colors.secondary.base,
                    hoverBackgroundColor: colors.secondary.light,
                    borderRadius: 8,
                    borderSkipped: false,
                    barPercentage: 0.6,
                    categoryPercentage: 0.7
                }]
            },
            options: {
                ...commonOptions,
                plugins: {
                    ...commonOptions.plugins,
                    legend: {
                        display: false
                    },
                    datalabels: {
                        anchor: 'end',
                        align: 'top',
                        offset: 4,
                        display: function(context) {
                            return context.dataIndex < 5; // Solo mostrar para los 5 primeros
                        }
                    }
                },
                scales: {
                    ...commonOptions.scales,
                    y: {
                        ...commonOptions.scales.y,
                        title: {
                            display: true,
                            text: 'Ingresos (S/.)',
                            font: {
                                family: fontFamily,
                                size: 13,
                                weight: '500'
                            },
                            color: '#6B7280',
                            padding: {
                                top: 0,
                                bottom: 10
                            }
                        }
                    }
                }
            }
        });

        // Ingresos por Categoría (Barras horizontales)
        const categoriaCtx = document.getElementById('categoriaChart').getContext('2d');

        // Crear colores para cada barra
        const categoryColors = [
            colors.tertiary.base,
            colors.quaternary.base,
            colors.primary.base,
            colors.secondary.base,
            '#10B981', // Verde
            '#8B5CF6', // Violeta
            '#06B6D4', // Cyan
            '#EF4444' // Rojo
        ];

        const categoryHoverColors = [
            colors.tertiary.light,
            colors.quaternary.light,
            colors.primary.light,
            colors.secondary.light,
            '#34D399', // Verde claro
            '#A78BFA', // Violeta claro
            '#22D3EE', // Cyan claro
            '#F87171' // Rojo claro
        ];

        // Obtener datos y ordenarlos de mayor a menor
        const categoriaData = @json($ingresosPorCategoria);
        const sortedCategories = Object.keys(categoriaData).sort((a, b) => categoriaData[b] - categoriaData[a]);
        const sortedValues = sortedCategories.map(cat => categoriaData[cat]);

        // Limitar a 8 categorías para mejor visualización
        const displayCategories = sortedCategories.slice(0, 8);
        const displayValues = sortedValues.slice(0, 8);

        new Chart(categoriaCtx, {
            type: 'bar',
            data: {
                labels: displayCategories,
                datasets: [{
                    label: 'Ingresos',
                    data: displayValues,
                    backgroundColor: displayCategories.map((_, i) => categoryColors[i % categoryColors
                        .length]),
                    hoverBackgroundColor: displayCategories.map((_, i) => categoryHoverColors[i %
                        categoryHoverColors.length]),
                    borderRadius: 8,
                    borderSkipped: false,
                    barPercentage: 0.75,
                    categoryPercentage: 0.8
                }]
            },
            options: {
                ...commonOptions,
                indexAxis: 'y',
                plugins: {
                    ...commonOptions.plugins,
                    legend: {
                        display: false
                    },
                    datalabels: {
                        align: 'right',
                        anchor: 'end',
                        formatter: function(value) {
                            return value.toLocaleString('es-ES', {
                                style: 'currency',
                                currency: 'EUR',
                                minimumFractionDigits: 0,
                                maximumFractionDigits: 0
                            });
                        },
                        color: '#111827',
                        font: {
                            weight: '600'
                        },
                        padding: {
                            right: 6
                        }
                    }
                },
                scales: {
                    x: {
                        ...commonOptions.scales.y, // Intercambiamos x e y porque es horizontal
                        title: {
                            display: true,
                            text: 'Ingresos (S/.)',
                            font: {
                                family: fontFamily,
                                size: 13,
                                weight: '500'
                            },
                            color: '#6B7280',
                            padding: {
                                top: 10,
                                bottom: 0
                            }
                        }
                    },
                    y: {
                        ...commonOptions.scales.x, // Intercambiamos x e y porque es horizontal
                        ticks: {
                            font: {
                                family: fontFamily,
                                size: 12,
                                weight: '500'
                            },
                            color: '#4B5563'
                        }
                    }
                }
            }
        });
    </script>

</div>
