<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <!-- Título del sitio (aparece en la pestaña del navegador) -->
    <title>Linhs Llantas | Panel Administrativo</title>

    <!-- Ícono del sitio (favicon) -->
    <link rel="icon" href="{{ asset('storage/pageweb/logopeque.png') }}" type="image/png">

    <!-- Fonts -->
    <link rel="stylesheet" href="build/assets/app-C8weeuyp.css">
    <script src="build/assets/app-Xaw6OIO1.js"></script>
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <!-- Vite -->
    @vite(['resources/css/app.css', 'resources/js/app.js'])

    <!-- Livewire Styles -->
    @livewireStyles
</head>

<body>
    <!-- Contenedor principal -->
    <div class="flex h-screen">
        <!-- Menú de navegación lateral -->
        <div>
            @livewire('navigation-menudos')
        </div>

        <!-- Área principal -->
        <div class="flex-1 flex flex-col">
            <!-- Encabezado -->
            <div>
                @livewire('header')
            </div>

            <!-- Contenido dinámico -->
            <div class="p-4 flex-1">
                {{ $slot }}
            </div>
        </div>
    </div>

    <!-- Modales -->
    @stack('modals')

    <!-- Livewire Scripts -->
    @livewireScripts
</body>

</html>
