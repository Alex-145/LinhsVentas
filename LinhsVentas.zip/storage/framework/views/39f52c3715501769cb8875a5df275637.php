<?php if (isset($component)) { $__componentOriginal4b816286c686080c15f7921b3fe65677 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4b816286c686080c15f7921b3fe65677 = $attributes; } ?>
<?php $component = App\View\Components\IndexLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('index-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\IndexLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="bg-gray-50">
        <!-- Hero Section -->

        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('pageweb.scam-alert');

$__html = app('livewire')->mount($__name, $__params, 'lw-3356207069-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        <section class="relative bg-gradient-to-r from-blue-600 to-blue-800 text-white overflow-hidden h-screen">
            <!-- Imagen de fondo con gradiente encima -->
            <div class="absolute right-0 top-0 h-full w-1/2 hidden lg:block">
                <div class="relative h-full w-full">
                    <img src="<?php echo e(asset('storage/pageweb/llantalogoinicio.jpg')); ?>" alt="Llantas"
                        class="absolute inset-0 h-full w-full object-cover z-0">
                    <div class="absolute inset-0 bg-gradient-to-l from-transparent to-blue-800 opacity-90 z-10"></div>
                </div>
            </div>

            <!-- Contenido del hero -->
            <div class="container mx-auto px-4 h-full flex flex-col lg:flex-row items-center relative z-20">
                <div class="lg:w-1/2 text-center lg:text-left lg:pl-12">
                    <h1 class="text-5xl font-extrabold leading-tight mb-6 tracking-tight drop-shadow-lg">
                        Bienvenido a <span class="text-yellow-400">LINHSLLANTAS</span>
                    </h1>
                    <p
                        class="text-xl text-blue-100 font-light mb-8 leading-relaxed max-w-xl mx-auto lg:mx-0 drop-shadow">
                        Te ofrecemos una amplia gama de llantas y productos especializados para el mantenimiento de tu
                        vehículo. Calidad, seguridad y servicio garantizados.
                    </p>
                    <a href="<?php echo e(route('wproducts.index')); ?>"
                        class="inline-block bg-yellow-400 hover:bg-yellow-500 text-black font-semibold py-3 px-8 rounded-full shadow-xl transition-all duration-300 transform hover:scale-105">
                        Explorar Productos
                    </a>

                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('pageweb.seguir-pedido');

$__html = app('livewire')->mount($__name, $__params, 'lw-3356207069-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>
            </div>
        </section>








        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('pageweb.top-products');

$__html = app('livewire')->mount($__name, $__params, 'lw-3356207069-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>



        <!-- Modal - Aviso contra Estafas -->
        <div id="fraud-warning-modal"
            class="fixed inset-0 bg-gray-800 bg-opacity-50 flex justify-center items-center hidden z-50">
            <div class="bg-white p-6 rounded-lg shadow-lg w-11/12 md:w-1/3">
                <h3 class="text-xl font-semibold mb-4">¡Alerta de Estafa!</h3>
                <p class="mb-4 text-gray-700">Por favor, ten en cuenta que no nos hacemos responsables de ventas fuera
                    de nuestra página web oficial. No caigas en estafas. Si tienes dudas, contacta directamente con
                    nuestro servicio al cliente.</p>
                <button onclick="closeModal()"
                    class="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg">Cerrar</button>
            </div>
        </div>


    </div>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4b816286c686080c15f7921b3fe65677)): ?>
<?php $attributes = $__attributesOriginal4b816286c686080c15f7921b3fe65677; ?>
<?php unset($__attributesOriginal4b816286c686080c15f7921b3fe65677); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4b816286c686080c15f7921b3fe65677)): ?>
<?php $component = $__componentOriginal4b816286c686080c15f7921b3fe65677; ?>
<?php unset($__componentOriginal4b816286c686080c15f7921b3fe65677); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\LinhsVentas\resources\views/livewire/pageweb/inicio.blade.php ENDPATH**/ ?>