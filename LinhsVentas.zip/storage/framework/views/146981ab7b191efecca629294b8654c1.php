<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Título del sitio (aparece en la pestaña del navegador) -->
    <title>Linhs Llantas | Panel Administrativo</title>

    <!-- Ícono del sitio (favicon) -->
    <link rel="icon" href="<?php echo e(asset('storage/pageweb/logopeque.png')); ?>" type="image/png">

    <!-- Fonts -->
    <link rel="stylesheet" href="build/assets/app-C8weeuyp.css">
    <script src="build/assets/app-Xaw6OIO1.js"></script>
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <!-- Vite -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <!-- Livewire Styles -->
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>

<body>
    <!-- Contenedor principal -->
    <div class="flex h-screen">
        <!-- Menú de navegación lateral -->
        <div>
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('navigation-menudos');

$__html = app('livewire')->mount($__name, $__params, 'lw-2875571227-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>

        <!-- Área principal -->
        <div class="flex-1 flex flex-col">
            <!-- Encabezado -->
            <div>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('header');

$__html = app('livewire')->mount($__name, $__params, 'lw-2875571227-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>

            <!-- Contenido dinámico -->
            <div class="p-4 flex-1">
                <?php echo e($slot); ?>

            </div>
        </div>
    </div>

    <!-- Modales -->
    <?php echo $__env->yieldPushContent('modals'); ?>

    <!-- Livewire Scripts -->
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

</body>

</html>
<?php /**PATH C:\laragon\www\LinhsVentas\resources\views/layouts/app.blade.php ENDPATH**/ ?>