<div class="fixed inset-0 flex items-center justify-center bg-gray-900 bg-opacity-50 z-50">
    <div class="bg-white p-6 rounded-lg w-96 shadow-xl">
        <h2 class="text-xl font-semibold mb-4">Nuevo Cliente</h2>
        <form wire:submit.prevent="store">
            <div class="mb-4">
                <label for="dni" class="block text-sm font-medium text-gray-700">DNI</label>
                <div class="flex space-x-2">
                    <input type="text" id="dni" wire:model.defer="dni"
                        class="w-full p-2 border border-gray-300 rounded-lg" placeholder="Ingrese DNI" />
                    <button type="button" wire:click="buscarDni"
                        class="px-3 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Buscar</button>
                </div>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['dni'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
            <div class="mb-4">
                <label for="name" class="block text-sm font-medium text-gray-700">Nombre</label>
                <input type="text" id="name" wire:model="name"
                    class="w-full p-2 border border-gray-300 rounded-lg" placeholder="Ingrese el Nombre" required />
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>


            <div class="mb-4">
                <label for="ruc" class="block text-sm font-medium text-gray-700">RUC</label>
                <div class="flex space-x-2">
                    <input type="text" id="ruc" wire:model.defer="ruc"
                        class="w-full p-2 border border-gray-300 rounded-lg" placeholder="Ingrese RUC" />
                    <button type="button" wire:click="buscarRuc"
                        class="px-3 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Buscar</button>
                </div>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['ruc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
            <div class="mb-4">
                <label for="business_name" class="block text-sm font-medium text-gray-700">Razón Social</label>
                <input type="text" id="business_name" wire:model="business_name"
                    class="w-full p-2 border border-gray-300 rounded-lg" placeholder="Ingrese la Razón Social" />
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['business_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
            <div class="mb-4">
                <label for="phone_number" class="block text-sm font-medium text-gray-700">Número de Teléfono</label>
                <input type="text" id="phone_number" wire:model="phone_number"
                    class="w-full p-2 border border-gray-300 rounded-lg" placeholder="Ingrese el Número de Teléfono" />
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
            <div class="mb-4">
                <label for="email" class="block text-sm font-medium text-gray-700">Correo Electrónico</label>
                <input type="email" id="email" wire:model="email"
                    class="w-full p-2 border border-gray-300 rounded-lg" placeholder="Ingrese el Correo Electrónico" />
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
            <div class="flex justify-end">
                <button type="button" wire:click="closeModal"
                    class="px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600">
                    Cancelar
                </button>
                <button type="submit" class="ml-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">
                    Guardar
                </button>
            </div>
        </form>
    </div>
</div>
<?php /**PATH C:\laragon\www\LinhsVentas\resources\views/livewire/client-form.blade.php ENDPATH**/ ?>