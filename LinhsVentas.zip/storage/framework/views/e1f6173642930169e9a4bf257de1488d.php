<div class="max-w-4xl mx-auto p-6 bg-white shadow-lg rounded-lg">
    <div class="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
        <!-- Imagen del producto -->
        <div>
            <img src="<?php echo e(asset('storage/' . $product->photo_url)); ?>" alt="<?php echo e($product->name); ?>"
                class="w-full h-auto rounded-lg shadow-md">
        </div>

        <!-- Detalles del producto -->
        <div>
            <!--[if BLOCK]><![endif]--><?php if($product->brand): ?>
                <div class="flex justify-center mb-4">
                    <img src="<?php echo e(asset('storage/' . $product->brand->url_imgbrand)); ?>" alt="<?php echo e($product->brand->name); ?>"
                        class="w-24 h-24 object-contain">
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <h1 class="text-3xl font-bold text-gray-900 flex items-center gap-2">
                <i class="fas fa-tag text-blue-600"></i> <?php echo e($product->name); ?>

            </h1>

            <!--[if BLOCK]><![endif]--><?php if($product->brand): ?>
                <p class="text-gray-600 text-sm flex items-center gap-2 mt-2">
                    <i class="fas fa-industry text-gray-500"></i> Marca: <?php echo e($product->brand->name); ?>

                </p>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <!--[if BLOCK]><![endif]--><?php if($product->stock > 0): ?>
                <p class="text-green-600 mt-2 flex items-center gap-2">
                    <i class="fas fa-box text-green-500"></i> Stock disponible: <?php echo e($product->stock); ?>

                </p>
            <?php else: ?>
                <p class="text-red-600 font-bold mt-2 flex items-center gap-2">
                    <i class="fas fa-exclamation-circle text-red-500"></i> Producto agotado
                </p>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <!-- Precio -->
            <!--[if BLOCK]><![endif]--><?php if($product->stock > 0): ?>
                <div class="flex items-center justify-between mt-4">
                    <span class="text-2xl font-bold text-blue-600 flex items-center gap-2">
                        S/.<?php echo e(number_format($product->sale_price, 2)); ?>

                    </span>
                </div>
                <!-- Botón de añadir al carrito -->
                <!--[if BLOCK]><![endif]--><?php if(isset($cart[$product->id]) && $cart[$product->id]['quantity'] >= $product->stock): ?>
                    <span class="block text-center text-yellow-600 font-bold mt-2">Stock limitado</span>
                <?php else: ?>
                    <button wire:click="addToCart"
                        class="w-full mt-4 px-4 py-2 rounded-full font-semibold text-white transition-all duration-300
            <?php echo e(isset($cart[$product->id]) ? 'bg-gray-500 hover:bg-gray-600' : 'bg-green-500 hover:bg-green-600'); ?>">
                        <i class="fas fa-cart-plus"></i>
                        <?php echo e(isset($cart[$product->id]) ? 'Añadir uno más' : 'Añadir al carrito'); ?>

                    </button>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->




        </div>
    </div>

    <!-- Atributos del producto -->
    <div class="mt-6">
        <h3 class="text-lg font-semibold text-gray-700 flex items-center gap-2">
            <i class="fas fa-list text-gray-600"></i> Características:
        </h3>
        <ul class="mt-2 text-gray-600 space-y-1">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $product->attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="flex items-center gap-2">
                    <i class="fas fa-check-circle text-green-500"></i> <?php echo e($attribute->name); ?>:
                    <?php echo e($attribute->pivot->value); ?>

                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </ul>
    </div>
</div>
<?php /**PATH C:\laragon\www\LinhsVentas\resources\views/livewire/pageweb/product-show.blade.php ENDPATH**/ ?>