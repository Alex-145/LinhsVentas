<?php

namespace App\Livewire;

use App\Models\Sale;
use App\Models\SaleDetail;
use App\Models\Brand;
use App\Models\Category;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Livewire\Component;

class DashboardChart extends Component
{
    public $menuAbierto = true;
    public $fechaInicio;
    public $fechaFin;
    public $marcaSeleccionada = '';
    public $categoriaSeleccionada = '';

    protected $listeners = ['toggleMenu' => 'updateMenuState'];

    public function mount()
    {
        // Establecer valores por defecto para los filtros (todo el año actual)
        $this->fechaInicio = Carbon::createFromDate(date('Y'), 1, 1)->format('Y-m-d');
        $this->fechaFin = Carbon::now()->format('Y-m-d');
    }



    public function updateMenuState()
    {
        $this->menuAbierto = !$this->menuAbierto;
    }

    public function aplicarFiltros()
    {
        // Este método se dispara cuando se hace clic en "Aplicar Filtros"
        // No necesitamos hacer nada aquí porque los datos se actualizan automáticamente
        // gracias a las propiedades reactivas de Livewire
    }

    public function resetearFiltros()
    {
        $this->reset(['fechaInicio', 'fechaFin', 'marcaSeleccionada', 'categoriaSeleccionada']);
        $this->fechaFin = Carbon::now()->format('Y-m-d');
        $this->fechaInicio = Carbon::now()->subDays(30)->format('Y-m-d');
    }

    public function render()
    {
        // Consulta base para ventas con filtros
        $queryVentas = Sale::query()
            ->whereBetween('sale_date', [$this->fechaInicio, $this->fechaFin]);

        $queryDetalles = SaleDetail::query()
            ->join('sales', 'sale_details.sale_id', '=', 'sales.id')
            ->whereBetween('sales.sale_date', [$this->fechaInicio, $this->fechaFin]);

        // Aplicar filtro de marca si está seleccionada
        if ($this->marcaSeleccionada) {
            $queryDetalles = $queryDetalles
                ->join('products', function ($join) {
                    $join->on('products.id', '=', 'sale_details.salable_id')
                        ->where('sale_details.salable_type', 'App\Models\Product');
                })
                ->where('products.brand_id', $this->marcaSeleccionada);
        }

        // Aplicar filtro de categoría si está seleccionada
        if ($this->categoriaSeleccionada) {
            $queryDetalles = $queryDetalles
                ->join('products', function ($join) {
                    $join->on('products.id', '=', 'sale_details.salable_id')
                        ->where('sale_details.salable_type', 'App\Models\Product');
                })
                ->join('brands', 'products.brand_id', '=', 'brands.id')
                ->where('brands.category_id', $this->categoriaSeleccionada);
        }

        // KPIs
        $totalVentas = $queryVentas->sum('total');
        $totalTransacciones = $queryVentas->count();
        $ventaPromedio = $totalTransacciones > 0 ? $totalVentas / $totalTransacciones : 0;
        $totalProductos = $queryDetalles->sum('quantity');

        // Ventas por Fecha (filtradas)
        $ventasPorFecha = $queryVentas
            ->select(DB::raw("DATE(sale_date) as fecha"), DB::raw("SUM(total) as total"))
            ->groupBy('fecha')
            ->orderBy('fecha')
            ->pluck('total', 'fecha')
            ->toArray();

        // Ingresos por Marca (filtrados)
        $ingresosPorMarca = SaleDetail::select('brands.name as marca', DB::raw("SUM(sale_details.subtotal) as total"))
            ->join('sales', 'sale_details.sale_id', '=', 'sales.id')
            ->join('products', function ($join) {
                $join->on('products.id', '=', 'sale_details.salable_id')
                    ->where('sale_details.salable_type', 'App\Models\Product');
            })
            ->join('brands', 'products.brand_id', '=', 'brands.id')
            ->whereBetween('sales.sale_date', [$this->fechaInicio, $this->fechaFin])
            ->when($this->marcaSeleccionada, function ($query) {
                return $query->where('brands.id', $this->marcaSeleccionada);
            })
            ->when($this->categoriaSeleccionada, function ($query) {
                return $query->where('brands.category_id', $this->categoriaSeleccionada);
            })
            ->groupBy('brands.name')
            ->pluck('total', 'marca')
            ->toArray();

        // Ingresos por Categoría (filtrados)
        $ingresosPorCategoria = SaleDetail::select('categories.name as categoria', DB::raw("SUM(sale_details.subtotal) as total"))
            ->join('sales', 'sale_details.sale_id', '=', 'sales.id')
            ->join('products', function ($join) {
                $join->on('products.id', '=', 'sale_details.salable_id')
                    ->where('sale_details.salable_type', 'App\Models\Product');
            })
            ->join('brands', 'products.brand_id', '=', 'brands.id')
            ->join('categories', 'brands.category_id', '=', 'categories.id')
            ->whereBetween('sales.sale_date', [$this->fechaInicio, $this->fechaFin])
            ->when($this->marcaSeleccionada, function ($query) {
                return $query->where('brands.id', $this->marcaSeleccionada);
            })
            ->when($this->categoriaSeleccionada, function ($query) {
                return $query->where('categories.id', $this->categoriaSeleccionada);
            })
            ->groupBy('categories.name')
            ->pluck('total', 'categoria')
            ->toArray();

        // Obtener marcas y categorías para los filtros
        $marcas = Brand::orderBy('name')->get();
        $categorias = Category::orderBy('name')->get();

        return view('livewire.dashboard-chart', [
            'totalVentas' => $totalVentas,
            'ventaPromedio' => $ventaPromedio,
            'totalProductos' => $totalProductos,
            'totalTransacciones' => $totalTransacciones,
            'ventasPorFecha' => $ventasPorFecha,
            'ingresosPorMarca' => $ingresosPorMarca,
            'ingresosPorCategoria' => $ingresosPorCategoria,
            'marcas' => $marcas,
            'categorias' => $categorias,
        ]);
    }
}
