<div x-data="carousel()"
     x-init="startAutoPlay"
     @keydown.right="next"
     @keydown.left="prev"
     class="relative w-full max-w-4xl mx-auto">
    <!-- Carousel Wrapper -->
    <div class="relative overflow-hidden rounded-lg shadow-lg aspect-w-16 aspect-h-9">
        <div x-ref="carousel" class="flex transition-transform duration-500 ease-in-out">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- Use x-show to display only the current image -->
                <div :class="{'opacity-0': currentIndex !== <?php echo e($index); ?>}"
                     x-transition:enter="transition-opacity duration-300"
                     x-transition:leave="transition-opacity duration-300"
                     class="w-full h-full flex-shrink-0">
                    <img src="<?php echo e(asset('storage/' . $image)); ?>" alt="carousel image" class="w-full h-full object-cover">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>

    <!-- Previous and Next Buttons -->
    <button @click="prev" @keydown.enter="prev"
            class="absolute left-4 top-1/2 transform -translate-y-1/2 bg-black bg-opacity-50 text-white rounded-full p-2 opacity-75 hover:opacity-100 transition focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-white">
        <svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
            <path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7"></path>
        </svg>
    </button>

    <button @click="next" @keydown.enter="next"
            class="absolute right-4 top-1/2 transform -translate-y-1/2 bg-black bg-opacity-50 text-white rounded-full p-2 opacity-75 hover:opacity-100 transition focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-white">
        <svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
            <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"></path>
        </svg>
    </button>

    <!-- Indicators -->
    <div class="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button @click="currentIndex = <?php echo e($index); ?>" @keydown.enter="currentIndex = <?php echo e($index); ?>"
                    class="w-3 h-3 rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-white"
                    :class="currentIndex === <?php echo e($index); ?> ? 'bg-white' : 'bg-gray-600 hover:bg-gray-400'">
            </button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</div>

<script>
function carousel() {
    return {
        currentIndex: <?php if ((object) ('currentIndex') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('currentIndex'->value()); ?>')<?php echo e('currentIndex'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('currentIndex'); ?>')<?php endif; ?>,
        total: <?php echo e(count($images)); ?>,
        startAutoPlay() {
            setInterval(() => {
                this.next();
            }, 5000); // Change slide every 5 seconds
        },
        next() {
            this.currentIndex = (this.currentIndex + 1) % this.total;
            this.updateTransform();
        },
        prev() {
            this.currentIndex = (this.currentIndex - 1 + this.total) % this.total;
            this.updateTransform();
        },
        updateTransform() {
            const offset = -this.currentIndex * 100;
            this.$refs.carousel.style.transform = `translateX(${offset}%)`;
        }
    }
}
</script>
<?php /**PATH C:\laragon\www\LinhsVentas\resources\views/livewire/pageweb/inicio/carousel.blade.php ENDPATH**/ ?>